import java.util.*;


/**
 *  A class to study merging.  
 *
 *  @author Jason Quesenberry and Nancy Quesenberry
 *  @created January 16, 2006
 */

public class Merge{
 
  public void merge (ArrayList <Comparable> a, ArrayList <Comparable> b, ArrayList <Comparable> c)
  {

  }

  /**
   *  Initializes and returns temp with random integers in the range
   *  1 to largestInt
   *
   * @return  an ArrayList of size specified by the user filled
   *          with random numbers
   */
  public ArrayList <Comparable> fillArray()
  {
  }

  /**
   *  Prints out the contents of the array in tabular form, 20 columns
   */
  public void screenOutput(ArrayList <Comparable> temp)
  {
  }

}

