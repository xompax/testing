#include <math.h>
#include <iostream.h>
#include "apvector.h"
#include "apvector.cc"
#include "apstring.h"
#include "apstring.cc"

template<class Item>
Print(const apvector<Item> & list, int numElts)
{
    int k;
    for(k=0; k < numElts; k++)
    {
        cout << list[k] << " ";
    }
    cout << endl;
}

main()
{
    apvector<int> ilist(20);
    apvector<double> dlist;
    apvector<apstring> slist(15,"apcs");

    int k;
    for (k=0; k < 20; k++)
    {
        ilist[k] = k;
    }

    cout << "int\t";    Print(ilist,20);
    cout << "double\t"; Print(dlist,0);
    cout << "string\t"; Print(slist,15);

    dlist.resize(17);
    for(k=0; k < 17; k++)
    {
        dlist[k] = sqrt(k);
    }
    Print(dlist,17);
//    Print(dlist,20);
    cout << dlist[-1] << endl;
}
