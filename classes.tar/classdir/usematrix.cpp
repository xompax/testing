#include <iostream.h>
#include "apstring.h"
#include "apstring.cc"
#include "apmatrix.h"
#include "apmatrix.cc"
#include "apvector.cc"

template <class Item>
Print(const apmatrix<Item> & mat, int nr, int nc)
{
    int j,k;
    for(j=0; j < nr; j++)
    {
        for(k=0; k < nc; k++)
        {
            cout << mat[j][k] << " ";
        }
        cout << endl;
    }
}


main()
{
    apmatrix<int>          imat(3,4,22);
    apmatrix<double>       dmat;
    apmatrix<apstring>     smat(5,3,"apple");
    apmatrix<apstring>     smat2(3,4,"pears");

    cout << "int\t";    Print(imat,3,4);
    cout << "double\t"; Print(dmat,0,0);
    cout << "string\t"; Print(smat,5,3);
    cout << "string\t"; Print(smat2,3,4);

    apmatrix<apstring> dummy(smat);
    cout << "string copy\t"; Print(dummy,5,3);
    
    smat = smat2;
    cout << "string assign\t"; Print(smat,3,4);
}

