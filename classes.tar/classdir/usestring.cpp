#include <iostream.h>
#include "apstring.h"
#include "apstring.cc"

int main()
{
    apstring a = "hello";
    apstring b = a + " " + a;

    b += a;
    cout << b << endl;
    b += b;
    cout << b << endl;
    return 0;
}
