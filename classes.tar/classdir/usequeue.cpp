#include "apqueue.h"
#include "apvector.cc"
#include "apqueue.cc"
#include "apstring.h"
#include "apstring.cc"
#include <iostream.h>

template <class Item>
Print(const apqueue<Item> & s)
{
    apqueue<Item> copy(s);

    while (! copy.isEmpty())
    {
        cout << copy.front() << endl;
        copy.dequeue();
    }
    cout << "----------" << endl;
}

template <class Item>
DPrint(apqueue<Item> & s)
{

    while (!s.isEmpty())
    {
        cout << s.front() << endl;
        s.dequeue();
    }
    cout << "dprint ----------" << endl;
}


main()
{
    apstring names[] = {
        "ken","don","chris","susanh","susanr",
        "cary","theresa","franh","gail","marks",
        "markw","owen","mike","henry","barbara",
        "allen","frant","ron"
    };
    int numNames = sizeof(names)/sizeof(apstring);

    apqueue<int> iqueue;
    apqueue<apstring> squeue;
    int k;

    for(k=0; k < numNames; k++)
    {
        squeue.enqueue(names[k]);
        iqueue.enqueue(k);
    }

    cout << "num names = " << numNames << endl;
    Print(iqueue);
    Print(squeue);
    
    apqueue<int> iqueue2;

    iqueue2 = iqueue;
    Print(iqueue2);

    DPrint(squeue);
    DPrint(iqueue);    
}
