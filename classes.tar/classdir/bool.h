#ifndef _BOOL_H
#define _BOOL_H

typedef int bool;
const int false = 0;
const int true = 1;

#endif
